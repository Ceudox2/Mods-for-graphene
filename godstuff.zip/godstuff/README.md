This is just tools for server owners
nothing much
you cant craft them but you can get them with "/give [PLAYER] admincrap:[TOOL]"

install it by downloading the files from this repo and creating a folder in your mods folder named "admincrap" then copying the files in
