
survie_commande = {}
survie_commande.pos = {x=1726, y=17, z=-4571}

if minetest.setting_get_pos("zone_survie") then
    survie_commande.pos = minetest.setting_get_pos("zone_survie")
end

function teleportation_zone_survie(name)
    local player = minetest.get_player_by_name(name)
    if player == nil then
        -- just a check to prevent the server crashing
        return false
    end
    local pos = player:getpos()
    if pos.x>-20 and pos.x<20 and pos.z>-20 and pos.z<20 then
        minetest.chat_send_player(name, "Marche un peu la zone de survie est proche de toi!")
    elseif _G['cursed_world'] ~= nil and    --check global table for cursed_world mod
        cursed_world.location_y and cursed_world.dimension_y and
        pos.y < (cursed_world.location_y + cursed_world.dimension_y) and    --if player is in cursed world, stay in cursed world
        pos.y > (cursed_world.location_y - cursed_world.dimension_y)
    then   --check global table for cursed_world mod
        --minetest.chat_send_player(name, "T"..(cursed_world.location_y + cursed_world.dimension_y).." "..(cursed_world.location_y - cursed_world.dimension_y))
        local survie_pos = vector.round(survie_commande.pos);
        survie_pos.y = survie_pos.y + cursed_world.location_y;
        player:setpos(survie_pos)
        minetest.chat_send_player(name, "Teleportation a la zone de survie!")
    else
        player:setpos(survie_commande.pos)
        minetest.chat_send_player(name, "Teleportation a la zone de survie!")
    end
end

minetest.register_chatcommand("survie", {
    description = "Teleporte toi a la zone de survie.",
    func = teleportation_zone_survie,
})
