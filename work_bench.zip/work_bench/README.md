## Work Bench ##

##### A mod adding a Work Bench to Minetest. #####
##### The Work Bench can cut up to 12 shapes, repair your tools, craft items and store. #####

##### This mod is originating from [X-Decor](https://github.com/kilbith/xdecor). #####

![Preview](http://i.imgur.com/Pqg3G92.png)
![Preview2](http://i.imgur.com/cCR4FJc.png)
