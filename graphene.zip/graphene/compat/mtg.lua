local S = minetest.get_translator(minetest.get_current_modname())

-- Armor
--

if minetest.get_modpath("3d_armor") then
	armor:register_armor("graphene:helmet", {
		description = S("graphene Helmet"),
		inventory_image = "graphene_stuff_inv_helmet.png",
		light_source = 70, -- Texture will have a glow when dropped
		groups = {armor_head=1, armor_heal=20, armor_use=100, armor_fire=10},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, level=3},
		wear = 0,
	})

	armor:register_armor("graphene:chestplate", {
		description = S("graphene Chestplate"),
		inventory_image = "graphene_inv_chestplate.png",
		light_source = 70, -- Texture will have a glow when dropped
		groups = {armor_torso=1, armor_heal=20, armor_use=100, armor_fire=10},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=3},
		wear = 0,
	})

	armor:register_armor("graphene:leggings", {
		description = S("graphene Leggings"),
		inventory_image = "graphene_inv_leggings.png",
		light_source = 70, -- Texture will have a glow when dropped
		groups = {armor_legs=1, armor_heal=20, armor_use=100, armor_fire=10},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=3},
		wear = 0,
	})

	armor:register_armor("graphene:boots", {
		description = S("graphene Boots"),
		inventory_image = "graphene_inv_boots.png",
		light_source = 70, -- Texture will have a glow when dropped
		groups = {armor_feet=1, armor_heal=20, armor_use=100, armor_fire=10, physics_jump=0.5, physics_speed = 1},
		armor_groups = {fleshy=15},
		damage_groups = {cracky=2, snappy=1, level=3},
		wear = 0,
	})

	armor:register_armor("graphene:shield", {
		description = S("graphene Shield"),
		inventory_image = "graphene_inven_shield.png",
		light_source = 70, -- Texture will have a glow when dropped
		groups = {armor_shield=1, armor_heal=20, armor_use=100, armor_fire=10},
		armor_groups = {fleshy=20},
		damage_groups = {cracky=2, snappy=1, level=3},
		wear = 0,
	})
end

--
-- Ingot craft
--

minetest.register_craft({
	type = "shapeless",
	output = "graphene:ingot 2",
	recipe = {"default:mese_crystal", "graphene:orb"}
})

--
-- Orb craft
--

if not minetest.get_modpath("mobs_monster") then
	minetest.register_craft({
		output = "graphene:orb",
		recipe = {
			{"default:mese_crystal", "default:mese_crystal", "default:mese_crystal"},
			{"default:mese_crystal", "bucket:bucket_lava", "default:mese_crystal"},
			{"default:mese_crystal", "default:mese_crystal", "default:mese_crystal"}
		},
		replacements = {{"bucket:bucket_lava", "bucket:bucket_empty"}}
	})
end

--
-- Tool crafts
--

minetest.register_craft({
	output = "graphene:sword",
	recipe = {
		{"graphene:ingot"},
		{"graphene:ingot"},
		{"default:obsidian_shard"},
	}
})

minetest.register_craft({
	output = "graphene:pick",
	recipe = {
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"", "default:obsidian_shard", ""},
		{"", "default:obsidian_shard", ""},
	}
})

minetest.register_craft({
	output = "graphene:shovel",
	recipe = {
		{"graphene:ingot"},
		{"default:obsidian_shard"},
		{"default:obsidian_shard"},
	}
})

minetest.register_craft({
	output = "graphene:axe",
	recipe = {
		{"graphene:ingot", "graphene:ingot", ""},
		{"graphene:ingot", "default:obsidian_shard", ""},
		{"", "default:obsidian_shard", ""},
	}
})

--
-- Block crafts
--

minetest.register_craft({
	type = "shapeless",
	output = "graphene:ingot 9",
	recipe = {"graphene:block"}
})

minetest.register_craft({
	output = "graphene:block",
	recipe = {
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
	}
})

--
-- Lava in a Bottle craft
--

minetest.register_craft({
	output = "graphene:lava_in_a_bottle",
	recipe = {
		{"", "bucket:bucket_lava"},
		{"", "vessels:glass_bottle"},
	},
	replacements = {{"bucket:bucket_lava", "bucket:bucket_empty"}}
})
