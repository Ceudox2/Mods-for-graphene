local S = minetest.get_translator(minetest.get_current_modname())

for _, item in pairs({"graphene:sword", "graphene:pick", "graphene:axe", "graphene:shovel"}) do
	local itype = item:sub(item:find(":")+1)
	local mcldef = table.copy(minetest.registered_items[("mcl_tools:%s_diamond"):format(itype)])
	local groups = table.copy(minetest.registered_items[item].groups)

	mcldef.tool_capabilities.damage_groups.fleshy = mcldef.tool_capabilities.damage_groups.fleshy + 1
	mcldef.tool_capabilities.full_punch_interval = mcldef.tool_capabilities.full_punch_interval - 0.1
	groups.dig_speed_class = mcldef.groups.dig_speed_class

	minetest.override_item(item, {
		tool_capabilities = mcldef.tool_capabilities,
		groups = groups,
		wield_scale = vector.new(1.8, 1.8, 1),
		_repair_material = "graphene:ingot",
	})
end

minetest.override_item("graphene:block", {
	stack_max = 64,
	groups = {pickaxey=3, building_block=1},
	sounds = mcl_sounds.node_sound_stone_defaults(),
	_mcl_blast_resistance = 6,
	_mcl_hardness = 400,
})

for _, item in pairs({"graphene:ingot", "graphene:orb"}) do
	minetest.override_item(item, {
		stack_max = 64,
	})
end

minetest.register_tool("graphene:helmet",{
	description = S("graphene Helmet"),
	inventory_image = "graphene_stuff_inv_helmet.png",
	light_source = 70, -- Texture will have a glow when dropped
	groups = {armor_head=1, mcl_armor_points=3, mcl_armor_uses=100, mcl_armor_toughness=3},
	_repair_material = "graphene:ingot",
	sounds = {
		_mcl_armor_equip = "mcl_armor_equip_diamond",
		_mcl_armor_unequip = "mcl_armor_unequip_diamond",
	},
	on_place = armor.on_armor_use,
	on_secondary_use = armor.on_armor_use,
})

minetest.register_tool("graphene:chestplate", {
	description = S("graphene Chestplate"),
	inventory_image = "graphene_inv_chestplate.png",
	light_source = 70, -- Texture will have a glow when dropped
	groups = {armor_torso=1, mcl_armor_points=8, mcl_armor_uses=100, mcl_armor_toughness=3},
	_repair_material = "graphene:ingot",
	sounds = {
		_mcl_armor_equip = "mcl_armor_equip_diamond",
		_mcl_armor_unequip = "mcl_armor_unequip_diamond",
	},
	on_place = armor.on_armor_use,
	on_secondary_use = armor.on_armor_use,
})

minetest.register_tool("graphene:leggings", {
	description = S("graphene Leggings"),
	inventory_image = "graphene_inv_leggings.png",
	light_source = 70, -- Texture will have a glow when dropped
	groups = {armor_legs=1, mcl_armor_points=6, mcl_armor_uses=100, mcl_armor_toughness=3},
	_repair_material = "graphene:ingot",
	sounds = {
		_mcl_armor_equip = "mcl_armor_equip_diamond",
		_mcl_armor_unequip = "mcl_armor_unequip_diamond",
	},
	on_place = armor.on_armor_use,
	on_secondary_use = armor.on_armor_use,
})

minetest.register_tool("graphene:boots", {
	description = S("graphene Boots"),
	inventory_image = "graphene_inv_boots.png",
	light_source = 70, -- Texture will have a glow when dropped
	groups = {armor_feet=1, mcl_armor_points=3, mcl_armor_uses=100, mcl_armor_toughness=3},
	_repair_material = "graphene:ingot",
	sounds = {
		_mcl_armor_equip = "mcl_armor_equip_diamond",
		_mcl_armor_unequip = "mcl_armor_unequip_diamond",
	},
	on_place = armor.on_armor_use,
	on_secondary_use = armor.on_armor_use,
})

--
-- Ingot craft
--

minetest.register_craft({
	type = "shapeless",
	output = "graphene:ingot 2",
	recipe = {"mcl_mobitems:blaze_rod", "graphene:orb"}
})

--
-- Orb craft
--

minetest.register_craft({
	output = "graphene:orb",
	recipe = {
		{"mcl_mobitems:blaze_powder", "mcl_mobitems:magma_cream", "mcl_mobitems:blaze_powder"},
		{"mcl_mobitems:magma_cream", "mcl_buckets:bucket_lava", "mcl_mobitems:magma_cream"},
		{"", "mcl_mobitems:magma_cream", ""}
	},
	replacements = {{"mcl_buckets:bucket_lava", "mcl_buckets:bucket_empty"}}
})

--
-- Tool crafts
--

minetest.register_craft({
	output = "graphene:sword",
	recipe = {
		{"graphene:ingot"},
		{"graphene:ingot"},
		{"mcl_core:iron_ingot"},
	}
})

minetest.register_craft({
	output = "graphene:pick",
	recipe = {
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"", "mcl_core:iron_ingot", ""},
		{"", "mcl_core:iron_ingot", ""},
	}
})

minetest.register_craft({
	output = "graphene:shovel",
	recipe = {
		{"graphene:ingot"},
		{"mcl_core:iron_ingot"},
		{"mcl_core:iron_ingot"},
	}
})

minetest.register_craft({
	output = "graphene:axe",
	recipe = {
		{"graphene:ingot", "graphene:ingot", ""},
		{"graphene:ingot", "mcl_core:iron_ingot", ""},
		{"", "mcl_core:iron_ingot", ""},
	}
})

--
-- Block crafts
--

minetest.register_craft({
	type = "shapeless",
	output = "graphene:ingot 9",
	recipe = {"graphene:block"}
})

minetest.register_craft({
	output = "graphene:block",
	recipe = {
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
		{"graphene:ingot", "graphene:ingot", "graphene:ingot"},
	}
})

--
-- Lava in a Bottle craft
--

minetest.register_craft({
	output = "graphene:lava_in_a_bottle",
	recipe = {
		{"", "mcl_buckets:bucket_lava"},
		{"", "mcl_potions:glass_bottle"},
	},
	replacements = {{"mcl_buckets:bucket_lava", "mcl_buckets:bucket_empty"}}
})
